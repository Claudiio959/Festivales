import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Program {

	public static void main(String[] args) {
			
		Session session = HibernateUtilities.getSessionFactory().openSession();	
		session.beginTransaction();
		
		 Festival f = new Festival();
		 Actuacion a = new Actuacion();
		 Grupo g = new Grupo();
		 java.util.Date utilDate = new java.util.Date();
		 
		 f.setNombre("Medusa");
		 f.setLugar("Cullera");
		 f.setFecha(new java.sql.Date(utilDate.getTime()));
		 session.save(f);
		 
		 
		//* p.setFecha(new java.sql.Date(utilDate.getTime()));*//
		 
		a.setEscenario("Escenario 959");
		a.setHora(23);
		session.save(a);
		 
		 
		g.setNombre("Claudio");
		g.setEstilo("Trapeo");
		g.setNumero_miembros(5);
		session.save(g);
		 
		session.getTransaction().commit();
		
		session.beginTransaction();
		Festival fe = session.get(Festival.class,"Medusa");
		System.out.println("El nombre del festival es: "+fe.getNombre()+ " se encuentra en "+fe.getLugar()+" y su fecha empieza: "+fe.getFecha());
		
		Actuacion ac = session.get(Actuacion.class,23);
		System.out.println("Su primera actuacion sera a las "+ac.getHora()+" horas, en el escenario "+ac.getEscenario());
		
		Grupo gr = session.get(Grupo.class,"Claudio");
		System.out.println("El principal grupo es "+gr.getNombre()+" con el estilo de musica "+gr.getEstilo()+" el grupo formado por "+gr.getNumero_miembros()+" individuos");
		
		
		session.getTransaction().commit();
		
		session.close();
		HibernateUtilities.getSessionFactory().close();

	}

}
