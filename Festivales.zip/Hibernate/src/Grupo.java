
public class Grupo {
	private String nombre;
	private String estilo;
	private int numero_miembros;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEstilo() {
		return estilo;
	}
	public void setEstilo(String estilo) {
		this.estilo = estilo;
	}
	public int getNumero_miembros() {
		return numero_miembros;
	}
	public void setNumero_miembros(int numero_miembros) {
		this.numero_miembros = numero_miembros;
	}
}
