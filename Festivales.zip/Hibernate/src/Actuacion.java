
public class Actuacion {
	private int hora;
	private String Escenario;
	
	public int getHora() {
		return hora;
	}
	public void setHora(int hora) {
		this.hora = hora;
	}
	public String getEscenario() {
		return Escenario;
	}
	public void setEscenario(String escenario) {
		Escenario = escenario;
	}
}
